<?php
if(isset($_POST['name'], $_POST['email'], $_POST['message'])){
  echo 'Your name is'.$_POST['name'];
}
