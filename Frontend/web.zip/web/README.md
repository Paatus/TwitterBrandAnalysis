# TBA frontend
name pending
# Open Souce Used

'D3'              :  http://d3js.org/
'fullpage.js'          :  https://github.com/alvarotrigo/fullPage.js
'HighChart' : http://www.highcharts.com/
# HTML (Main folder)

	home.html

# CSS (Main folder)



# JavaScript (js folder)


# IMG

	video and image store inside

